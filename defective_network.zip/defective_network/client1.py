import os
import socket
import dsocket

SEND_BUFFER = 4096  # valor recomendado na doc. do python
#socket.socket = dsocket.deSocket

def getSize(filename):
    st = os.stat(filename)
    return st.st_size


def le_ficheiro():
    file = open('ficheiroteste.txt', 'r')
    for line in file:
        print(line, end='')

    file.close()

def bittstuffing(data):
    data = data[:20] + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + data[40:]
    print(data)


#socket.socket = dsocket.deSocket
print(getSize("ficheiroteste.txt"))
clientsocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
clientsocket.connect(('localhost', 5002))
if input("dowload ou upload? (d/u)") == "d":
    dowloadsignal = "DOWLOAD"
    sent = clientsocket.send(dowloadsignal.encode())
    if sent == 0:
        raise RuntimeError("socket connection broken")
    filename = input("Nome do ficheiro?")
    if filename != 'e':
        sent = clientsocket.send(filename.encode())
        if sent == 0:
            raise RuntimeError("socket connection broken")
        data = clientsocket.recv(SEND_BUFFER).decode()
        if data[:6] == 'EXISTE':
            filesize = int(data[6:])
            message = input("O ficheiro existe, quer fazer o dowload? (y/n)")
            if message == "y":
                confirmacao = "OK"
                sent = clientsocket.send(confirmacao.encode())
                if sent == 0:
                    raise RuntimeError("socket connection broken")
                f = open('new_'+filename, 'wb')
                data = clientsocket.recv(SEND_BUFFER)
                totalRecv = len(data)
                f.write(data)
                while totalRecv < filesize:
                    data = clientsocket.recv(SEND_BUFFER)
                    totalRecv += len(data)
                    f.write(data)
                    print ("{0:.2f}", format((totalRecv/float(filesize))*100)+ "% Done")
                print("Dowload completo")
        else:
            print("o ficheiro nao existe")
else:               ######################################################  UPLOAD
    dowloadsignal = "UPLOAD"
    sent = clientsocket.send(dowloadsignal.encode())
    if sent == 0:
        raise RuntimeError("socket connection broken")
    filename = input("Nome do ficheiro?")
    if filename != 'e':
        if os.path.isfile(filename):
            print("O ficheiro existe")
            sent = clientsocket.send(filename.encode())     #MANDA NOME FICHEIRO
            if sent == 0:
                raise RuntimeError("socket connection broken")
            print("cona1")
            strd = (str(os.path.getsize(filename)))
            userResponse = clientsocket.recv(SEND_BUFFER).decode()  #RECEBE CONFIRMACAO
            print(userResponse)
            if userResponse[:2] == "OK":
                clientsocket.send(strd.encode())    #MANDA TAMANHO DO FICHEIRO
                userResponse = clientsocket.recv(SEND_BUFFER).decode()  #RECEBE CONFIRMACAO
                print(userResponse)
                if userResponse[:2] == "OK":        #MANDA FICHEIRO
                    with open(filename, "rb") as f:
                        bytesToSend = f.read(SEND_BUFFER)
                        clientsocket.send(bytesToSend)
                        while bytesToSend != "":
                            bytesToSend = f.read(SEND_BUFFER)
                            clientsocket.send(bytesToSend)
        else:
            print("o ficheiro nao existe")
            erro = "ERR"
            clientsocket.send(erro.encode())
clientsocket.close()