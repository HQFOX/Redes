import socket
import threading
import os

SEND_BUFFER = 4096  # valor recomendado na doc. do python

def RetrFile(name, sock):
    escolha = sock.recv(SEND_BUFFER).decode()
    if escolha[:2] == "DO":            ############ SEND FILE
        filename = sock.recv(SEND_BUFFER).decode()
        if os.path.isfile(filename):
            strd = ("EXISTE "+ str(os.path.getsize(filename)))
            sock.send(strd.encode())
            userResponse = sock.recv(SEND_BUFFER).decode()
            if userResponse[:2] == "OK":
                with open(filename,"rb") as f:
                    bytesToSend = f.read(SEND_BUFFER)
                    sock.send(bytesToSend)
                    while bytesToSend != "":
                        bytesToSend = f.read(SEND_BUFFER)
                        sock.send(bytesToSend)
        else:
            erro = "ERR"
            sock.send(erro.encode())
    if escolha[:2] == "UP":                                         ######## RECIEVE FILE
        print("seccao de upload do server")
        filename = sock.recv(SEND_BUFFER).decode()
        confirmacao = "OK"
        print("nome do ficheiro ",filename)
        sent = sock.send(confirmacao.encode())
        filesize = int(sock.recv(SEND_BUFFER).decode())
        sent = sock.send(confirmacao.encode())
        f = open('recebido_' + filename, 'wb')
        data = sock.recv(SEND_BUFFER)
        totalRecv = len(data)
        f.write(data)
        while totalRecv < filesize:
            data = sock.recv(SEND_BUFFER)
            totalRecv += len(data)
            f.write(data)
            print("{0:.2f}", format((totalRecv / float(filesize)) * 100) + "% Done")
        print("Dowload completo")

def Main():
    host = '127.0.0.1'
    port = 5002

    s = socket.socket()
    s.bind((host,port))
    s.listen(5)

    print("O SERVIDOR INICIOU")
    while True:
        c, addr = s.accept()
        print(" client connected ip <" + str(addr)+">")
        t = threading.Thread(target=RetrFile, args=("retrThread" ,c))
        t.start()
    s.close()
if __name__ == '__main__':
    Main()